const JSON_HEADERS = { "content-type": "application/json; charset=utf-8" };
const allowedIntervals = new Set([7, 30, 60, 90]);

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
}

function isoNow() {
  return new Date().toISOString();
}

function validPhone(phone) {
  return typeof phone === "string" && /^\+[1-9]\d{7,14}$/.test(phone);
}

function addDays(dateString, days) {
  const d = new Date(dateString);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString();
}

async function authorized(request, env) {
  const header = request.headers.get("authorization") || "";
  const supplied = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!env.KIAN_BACKEND_SECRET || !supplied) return false;
  const a = new TextEncoder().encode(supplied);
  const b = new TextEncoder().encode(env.KIAN_BACKEND_SECRET);
  if (a.length !== b.length) return false;
  const digestA = await crypto.subtle.digest("SHA-256", a);
  const digestB = await crypto.subtle.digest("SHA-256", b);
  return crypto.subtle.timingSafeEqual
    ? crypto.subtle.timingSafeEqual(new Uint8Array(digestA), new Uint8Array(digestB))
    : [...new Uint8Array(digestA)].every((v, i) => v === new Uint8Array(digestB)[i]);
}

async function sendTemplate(env, reminder, key) {
  if (!env.WHATSAPP_ACCESS_TOKEN || !env.WHATSAPP_PHONE_NUMBER_ID) {
    throw new Error("WhatsApp credentials are not configured on the server");
  }
  const templateName = env.WHATSAPP_TEMPLATE_NAME || "kian_debt_reminder";
  const language = env.WHATSAPP_TEMPLATE_LANGUAGE || "ar";
  const url = `https://graph.facebook.com/v23.0/${env.WHATSAPP_PHONE_NUMBER_ID}/messages`;

  const body = {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to: reminder.phone.replace("+", ""),
    type: "template",
    template: {
      name: templateName,
      language: { code: language },
      components: [{
        type: "body",
        parameters: [
          { type: "text", text: reminder.customer_name },
          { type: "text", text: `${reminder.amount} ${reminder.currency}` },
          { type: "text", text: new Date(reminder.due_at).toLocaleDateString("en-GB", { timeZone: "UTC" }) }
        ]
      }]
    }
  };

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "authorization": `Bearer ${env.WHATSAPP_ACCESS_TOKEN}`,
      "content-type": "application/json",
      "x-kian-idempotency-key": key
    },
    body: JSON.stringify(body)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.messages?.[0]?.id) {
    throw new Error(result.error?.message || `Meta API returned HTTP ${response.status}`);
  }
  return result.messages[0].id;
}

async function deliver(env, reminder, source = "manual") {
  const key = `${reminder.customer_id}:${source}:${reminder.next_send_at}`;
  const existing = await env.DB.prepare(
    "SELECT id, status FROM message_logs WHERE idempotency_key = ?"
  ).bind(key).first();
  if (existing) return { accepted: existing.status === "accepted", duplicate: true };

  try {
    const messageId = await sendTemplate(env, reminder, key);
    await env.DB.prepare(
      `INSERT INTO message_logs (customer_id, phone, status, provider_message_id, idempotency_key)
       VALUES (?, ?, 'accepted', ?, ?)`
    ).bind(reminder.customer_id, reminder.phone, messageId, key).run();

    const next = addDays(isoNow(), reminder.interval_days);
    await env.DB.prepare(
      "UPDATE reminders SET last_sent_at = ?, next_send_at = ?, updated_at = ? WHERE customer_id = ?"
    ).bind(isoNow(), next, isoNow(), reminder.customer_id).run();
    return { accepted: true, providerMessageId: messageId };
  } catch (error) {
    await env.DB.prepare(
      `INSERT OR IGNORE INTO message_logs (customer_id, phone, status, error, idempotency_key)
       VALUES (?, ?, 'failed', ?, ?)`
    ).bind(reminder.customer_id, reminder.phone, String(error.message || error), key).run();
    return { accepted: false, error: String(error.message || error) };
  }
}

async function handle(request, env) {
  const url = new URL(request.url);
  if (request.method === "GET" && url.pathname === "/health") {
    return json({ ok: true, service: "kian-whatsapp-reminder", time: isoNow() });
  }

  if (!(await authorized(request, env))) return json({ error: "Unauthorized" }, 401);

  if (request.method === "POST" && url.pathname === "/api/reminders/upsert") {
    const data = await request.json().catch(() => null);
    if (!data || !data.customerId || !data.customerName || !validPhone(data.phone) ||
        data.amount == null || !data.dueAt || !allowedIntervals.has(Number(data.intervalDays))) {
      return json({ error: "Invalid reminder data. Use E.164 phone and interval 7/30/60/90." }, 400);
    }
    if (data.consent !== true) {
      await env.DB.prepare("UPDATE reminders SET consent = 0, active = 0, updated_at = ? WHERE customer_id = ?")
        .bind(isoNow(), String(data.customerId)).run();
      return json({ ok: true, active: false, reason: "No WhatsApp consent" });
    }
    const due = new Date(data.dueAt);
    if (Number.isNaN(due.getTime())) return json({ error: "Invalid dueAt date" }, 400);
    const nextSend = due.toISOString();
    await env.DB.prepare(`
      INSERT INTO reminders
      (customer_id, phone, customer_name, amount, currency, due_at, interval_days, consent, active, next_send_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
      ON CONFLICT(customer_id) DO UPDATE SET
      phone=excluded.phone, customer_name=excluded.customer_name, amount=excluded.amount,
      currency=excluded.currency, due_at=excluded.due_at, interval_days=excluded.interval_days,
      consent=1, active=excluded.active, next_send_at=excluded.next_send_at, updated_at=excluded.updated_at
    `).bind(
      String(data.customerId), data.phone, String(data.customerName), String(data.amount),
      String(data.currency || "EUR"), due.toISOString(), Number(data.intervalDays),
      data.active === false ? 0 : 1, nextSend, isoNow()
    ).run();
    return json({ ok: true, customerId: String(data.customerId), nextSendAt: nextSend });
  }

  if (request.method === "POST" && url.pathname === "/api/reminders/settle") {
    const data = await request.json().catch(() => ({}));
    if (!data.customerId) return json({ error: "customerId required" }, 400);
    await env.DB.prepare("UPDATE reminders SET active=0, updated_at=? WHERE customer_id=?")
      .bind(isoNow(), String(data.customerId)).run();
    return json({ ok: true, active: false });
  }

  if (request.method === "POST" && url.pathname === "/api/reminders/send-now") {
    const data = await request.json().catch(() => ({}));
    if (!data.customerId) return json({ error: "customerId required" }, 400);
    const reminder = await env.DB.prepare(
      "SELECT * FROM reminders WHERE customer_id=? AND active=1 AND consent=1"
    ).bind(String(data.customerId)).first();
    if (!reminder) return json({ error: "Active reminder with consent not found" }, 404);
    const result = await deliver(env, reminder, `manual-${crypto.randomUUID()}`);
    return json(result, result.accepted ? 200 : 502);
  }

  if (request.method === "GET" && url.pathname === "/api/reminders/logs") {
    const customerId = url.searchParams.get("customerId");
    const limit = Math.min(Math.max(Number(url.searchParams.get("limit") || 30), 1), 100);
    const query = customerId
      ? env.DB.prepare("SELECT customer_id, phone, status, provider_message_id, error, created_at FROM message_logs WHERE customer_id=? ORDER BY id DESC LIMIT ?").bind(customerId, limit)
      : env.DB.prepare("SELECT customer_id, phone, status, provider_message_id, error, created_at FROM message_logs ORDER BY id DESC LIMIT ?").bind(limit);
    const rows = await query.all();
    return json({ logs: rows.results || [] });
  }

  return json({ error: "Not found" }, 404);
}

async function scheduled(event, env, ctx) {
  const due = await env.DB.prepare(
    `SELECT * FROM reminders
     WHERE active=1 AND consent=1 AND next_send_at <= ?
     ORDER BY next_send_at ASC LIMIT 50`
  ).bind(isoNow()).all();

  for (const reminder of (due.results || [])) {
    ctx.waitUntil(deliver(env, reminder, "scheduled"));
  }
}

export default {
  fetch(request, env) {
    return handle(request, env);
  },
  scheduled(event, env, ctx) {
    return scheduled(event, env, ctx);
  }
};