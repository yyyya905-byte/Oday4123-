// مثال توضيحي يضاف إلى خادم Express الحالي بعد تكييف التحقق من جلسة الموظف.
// لا تضع KIAN_BACKEND_SECRET في الواجهة الأمامية أو في ملفات GitHub.
import express from "express";

const router = express.Router();

router.post("/api/kian-whatsapp/send-now", requireKianStaffSession, async (req, res) => {
  try {
    const { customerId } = req.body || {};
    if (!customerId) return res.status(400).json({ error: "customerId required" });

    // يجب قراءة هوية الزبون والدين من قاعدة كيان بعد التحقق من صلاحيات الموظف.
    // لا تثق بمبلغ أو رقم هاتف مرسل من المتصفح.
    const customer = await loadCustomerAndDebtFromKianDatabase(customerId);
    if (!customer || !customer.whatsappConsent || Number(customer.amountDue) <= 0) {
      return res.status(400).json({ error: "No payable debt or WhatsApp consent" });
    }

    const response = await fetch(`${process.env.KIAN_WHATSAPP_WORKER_URL}/api/reminders/send-now`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "authorization": `Bearer ${process.env.KIAN_BACKEND_SECRET}`
      },
      body: JSON.stringify({ customerId: String(customerId) })
    });
    const result = await response.json();
    return res.status(response.status).json(result);
  } catch (error) {
    return res.status(502).json({ error: "WhatsApp service unavailable" });
  }
});

export default router;